<?php

namespace Dao\Security;

final class Estados extends \Utilities\Enum
{
    const ACTIVO  = "ACT";
    const INACTIVO = "INA";
    const BLOQUEADO = "BLQ";
    const SUSPENDIDO = "SUS";
}
?>
