<?php
namespace Controllers\Mnt;

use Controllers\PublicController;
use Views\Renderer;

class Messages extends PublicController {
    public function run() :void
    {
        $viewData = array(
        
        );
        $viewData["messages"] = \Dao\Mnt\Messages::findAll();
        Renderer::render('mnt/messages', $viewData);}
}
?>