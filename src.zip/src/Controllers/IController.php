<?php

  namespace Controllers;

  interface IController
  {
    public function run() :void;
  }
?>
